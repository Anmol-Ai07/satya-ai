/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-rajdhani)', 'sans-serif'],
        mono: ['var(--font-space-mono)', 'monospace'],
        display: ['var(--font-orbitron)', 'sans-serif'],
      },
      colors: {
        void: '#050508',
        surface: '#0d0d18',
        panel: '#111127',
        border: '#1e1e3f',
        neon: {
          purple: '#9d4edd',
          violet: '#7b2ff7',
          blue: '#3a0ca3',
          pink: '#f72585',
          cyan: '#4cc9f0',
          green: '#06d6a0',
          red: '#ef233c',
          orange: '#fb8500',
          yellow: '#ffbe0b',
        },
      },
      animation: {
        'pulse-neon': 'pulseNeon 2s ease-in-out infinite',
        'scan': 'scan 2s linear infinite',
        'flicker': 'flicker 0.15s infinite',
        'glow-pulse': 'glowPulse 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'slide-up': 'slideUp 0.5s ease-out forwards',
        'fade-in': 'fadeIn 0.4s ease-out forwards',
        'spin-slow': 'spin 8s linear infinite',
        'radar': 'radar 2s linear infinite',
        'shimmer': 'shimmer 1.5s linear infinite',
      },
      keyframes: {
        pulseNeon: {
          '0%, 100%': { opacity: '1', filter: 'brightness(1)' },
          '50%': { opacity: '0.7', filter: 'brightness(1.4)' },
        },
        scan: {
          '0%': { transform: 'translateY(-100%)', opacity: '0.8' },
          '100%': { transform: 'translateY(400%)', opacity: '0' },
        },
        flicker: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.8' },
        },
        glowPulse: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(157, 78, 221, 0.4)' },
          '50%': { boxShadow: '0 0 40px rgba(157, 78, 221, 0.8), 0 0 80px rgba(157, 78, 221, 0.3)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        slideUp: {
          from: { opacity: '0', transform: 'translateY(30px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        radar: {
          from: { transform: 'rotate(0deg)' },
          to: { transform: 'rotate(360deg)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      backgroundImage: {
        'grid-pattern': `linear-gradient(rgba(157,78,221,0.05) 1px, transparent 1px),
          linear-gradient(90deg, rgba(157,78,221,0.05) 1px, transparent 1px)`,
        'neon-glow': 'radial-gradient(ellipse at center, rgba(157,78,221,0.15) 0%, transparent 70%)',
        'shimmer-gradient': 'linear-gradient(90deg, transparent 0%, rgba(157,78,221,0.3) 50%, transparent 100%)',
      },
      backgroundSize: {
        'grid': '40px 40px',
      },
      boxShadow: {
        'neon-sm': '0 0 10px rgba(157, 78, 221, 0.5)',
        'neon-md': '0 0 20px rgba(157, 78, 221, 0.6), 0 0 40px rgba(157, 78, 221, 0.3)',
        'neon-lg': '0 0 30px rgba(157, 78, 221, 0.8), 0 0 60px rgba(157, 78, 221, 0.4), 0 0 100px rgba(157, 78, 221, 0.2)',
        'neon-cyan': '0 0 20px rgba(76, 201, 240, 0.6)',
        'neon-green': '0 0 20px rgba(6, 214, 160, 0.6)',
        'neon-red': '0 0 20px rgba(239, 35, 60, 0.6)',
        'neon-yellow': '0 0 20px rgba(255, 190, 11, 0.6)',
        'inner-neon': 'inset 0 0 30px rgba(157, 78, 221, 0.1)',
      },
    },
  },
  plugins: [],
};
