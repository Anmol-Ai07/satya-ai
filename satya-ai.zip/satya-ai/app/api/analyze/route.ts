// app/api/analyze/route.ts
// Backend API route - API key never exposed to frontend

import { NextRequest, NextResponse } from "next/server";
import { analyzeWithGemini, fetchUrlContent } from "@/lib/gemini";

export const maxDuration = 60; // 60s timeout for Vercel

function isValidUrl(str: string): boolean {
  try {
    const url = new URL(str);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { type, content, imageBase64, imageMimeType } = body;

    // ─── Validation ─────────────────────────────────────────────────────────

    if (!type) {
      return NextResponse.json(
        { error: "Input type required" },
        { status: 400 }
      );
    }

    if (type === "image" && !imageBase64) {
      return NextResponse.json(
        { error: "Image data required" },
        { status: 400 }
      );
    }

    if (
      (type === "text" || type === "url" || type === "chat") &&
      (!content || content.trim().length === 0)
    ) {
      return NextResponse.json(
        { error: "Content cannot be empty" },
        { status: 400 }
      );
    }

    // ─── URL Processing ─────────────────────────────────────────────────────

    let urlContent: string | undefined;

    if (type === "url") {
      if (!isValidUrl(content.trim())) {
        return NextResponse.json(
          { error: "Invalid URL format" },
          { status: 400 }
        );
      }

      // Fetch URL content server-side
      urlContent = await fetchUrlContent(content.trim());
    }

    // ─── Determine if content is a fact-check or chat ──────────────────────

    let analysisType: "text" | "url" | "image" | "chat" = type;

    // Auto-detect: if text input looks like a casual question, use chat mode
    if (type === "text" && content) {
      const chatPatterns =
        /^(kya|what|how|who|when|where|why|bata|help|hi|hello|hey|namaste|hlo|tell me|explain|samjhao)/i;
      const isShortQuestion =
        content.trim().length < 60 && content.trim().endsWith("?");
      const isGreeting = /^(hi|hello|hey|namaste|hlo|yo)\b/i.test(
        content.trim()
      );

      if (isGreeting || (isShortQuestion && chatPatterns.test(content.trim()))) {
        analysisType = "chat";
      }
    }

    // ─── Call Gemini ─────────────────────────────────────────────────────────

    const result = await analyzeWithGemini({
      type: analysisType,
      content: content?.trim(),
      imageBase64,
      imageMimeType: imageMimeType || "image/jpeg",
      urlContent,
    });

    return NextResponse.json({ success: true, result });
  } catch (error: unknown) {
    console.error("Analysis error:", error);

    const message =
      error instanceof Error
        ? error.message
        : "Unknown error occurred";

    // Handle specific API errors
    if (message.includes("GOOGLE_API_KEY")) {
      return NextResponse.json(
        {
          error:
            "API key configure nahi hai. Please .env.local mein GOOGLE_API_KEY add karein.",
        },
        { status: 503 }
      );
    }

    if (message.includes("429") || message.includes("quota")) {
      return NextResponse.json(
        {
          error:
            "Rate limit exceed ho gaya. Thodi der baad try karein.",
        },
        { status: 429 }
      );
    }

    if (message.includes("400") || message.includes("invalid")) {
      return NextResponse.json(
        {
          error: "Invalid request. Please input check karein.",
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        error: `Analysis fail ho gaya: ${message}`,
      },
      { status: 500 }
    );
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}
