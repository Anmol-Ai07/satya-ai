// app/layout.tsx

import type { Metadata, Viewport } from "next";
import "@/styles/globals.css";

export const metadata: Metadata = {
  title: "SATYA AI — Truth Detection & Viral Content Engine",
  description:
    "India ka sabse advanced AI truth detector. Fake news, deepfakes, aur misinformation ko instantly detect karo. Powered by Gemini AI.",
  keywords: [
    "fake news detector",
    "truth detection",
    "deepfake detector",
    "fact check india",
    "satya ai",
    "misinformation",
  ],
  authors: [{ name: "SATYA AI" }],
  openGraph: {
    title: "SATYA AI — Truth Detection Engine",
    description: "Fake news aur deepfakes instantly detect karo",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#9d4edd",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="hi" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
      </head>
      <body className="antialiased bg-void min-h-screen">
        {children}
      </body>
    </html>
  );
}
