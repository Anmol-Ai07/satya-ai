// app/page.tsx

import SatyaAI from "@/components/SatyaAI";

export default function Home() {
  return (
    <main className="min-h-screen bg-void">
      <SatyaAI />
    </main>
  );
}
