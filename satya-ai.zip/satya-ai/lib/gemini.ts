// lib/gemini.ts
// Core Gemini API integration with Google Search grounding

const GEMINI_API_KEY = process.env.GOOGLE_API_KEY;
const GEMINI_ENDPOINT =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface AnalysisInput {
  type: "text" | "url" | "image" | "chat";
  content?: string;
  imageBase64?: string;
  imageMimeType?: string;
  urlContent?: string;
}

export interface AnalysisResult {
  isReal: boolean;
  confidence: number;
  verdict: "SAHI" | "GALAT" | "BHRAMAK" | "ASATYA";
  reasoning: string;
  redFlags: string[];
  suggestions: {
    hook: string;
    lighting: string;
    editing: string;
    contentTips: string[];
  };
  viralKit: {
    caption: string;
    hashtags: string[];
  };
  rawResponse?: string;
}

// ─── System Prompt ────────────────────────────────────────────────────────────

function buildSystemPrompt(): string {
  return `Tu SATYA AI hai — India ka sabse advanced truth detection aur viral content advisor.
Tu Hinglish mein baat karta hai — Hindi dominant, technical English allowed.

TERA KAAM:
- News / claim milne par → fact-check kar
- URL milne par → content verify kar, latest web knowledge use kar
- Image milne par → deepfake/manipulation detect kar
- Normal sawaal par → helpful chatbot ki tarah jawab de

VERDICT SYSTEM (STRICT):
- SAHI   = Real / Verified / True
- GALAT  = Fake / False / Fabricated
- BHRAMAK = Misleading / Partially true / Out of context
- ASATYA = Unverified / Cannot confirm

BAHUT IMPORTANT:
Hamesha SIRF ek valid JSON object return kar.
Koi extra text, markdown, code fences ya explanation mat de.
Sirf pure JSON.

Ye exact format follow kar:

{
  "isReal": true,
  "confidence": 85,
  "verdict": "SAHI",
  "reasoning": "2-3 line Hinglish explanation. Ye claim sahi hai kyunki...",
  "redFlags": ["Red flag 1 agar koi ho", "Red flag 2"],
  "suggestions": {
    "hook": "Engaging hook suggestion in English for this content",
    "lighting": "Lighting advice in English if applicable, else 'N/A'",
    "editing": "Editing tip in English for better engagement",
    "contentTips": ["Tip 1 in English", "Tip 2 in English", "Tip 3 in English"]
  },
  "viralKit": {
    "caption": "Catchy Hinglish caption jo viral ho sake 🔥",
    "hashtags": ["#SatyaAI", "#FactCheck", "#relevant", "#hashtag", "#india"]
  }
}

Agar normal chat question hai (koi claim/news/image nahi), tab bhi same JSON format use kar lekin verdict "SAHI" de aur reasoning mein chatbot jaisa jawab de.`;
}

// ─── Prompt Builder per input type ───────────────────────────────────────────

function buildUserPrompt(input: AnalysisInput): string {
  switch (input.type) {
    case "url":
      return `Ye URL analyze kar: ${input.content}

URL se extracted content:
"""
${input.urlContent || "Content extract nahi ho saka. URL ke basis par hi analyze kar."}
"""

Is URL ke content ko fact-check kar. Check kar ki ye:
1. Kya ye genuine source hai?
2. Headlines misleading toh nahi?
3. Claims verified hain ya nahi?
Latest web knowledge se verify kar.`;

    case "image":
      return `Is image ko analyze kar aur detect kar:
1. Kya ye image original hai ya edited/deepfake?
2. Koi manipulation ke signs hain?
3. Metadata ya visual artifacts suspicious hain?
4. AI-generated toh nahi lagti?

Detailed analysis de aur confidence score bata.`;

    case "chat":
      return `User ka sawaal: "${input.content}"

Is sawaal ka helpful Hinglish mein jawab de. Agar ye koi fact/claim hai toh verify kar.`;

    case "text":
    default:
      return `Ye text/claim analyze kar aur fact-check kar:

"""
${input.content}
"""

Check kar:
1. Kya ye claim sach hai?
2. Koi misleading information hai?
3. Sources reliable hain?
4. Recent events se match karta hai?

Latest web knowledge use karke verify kar.`;
  }
}

// ─── URL Content Fetcher ──────────────────────────────────────────────────────

export async function fetchUrlContent(url: string): Promise<string> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (compatible; SatyaAI/1.0; +https://satya-ai.vercel.app)",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5,hi;q=0.3",
      },
    });

    clearTimeout(timeout);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const html = await response.text();

    // Strip HTML tags and extract clean text
    const clean = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, " ")
      .replace(/<nav[^>]*>[\s\S]*?<\/nav>/gi, " ")
      .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, " ")
      .replace(/<header[^>]*>[\s\S]*?<\/header>/gi, " ")
      .replace(/<!--[\s\S]*?-->/g, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/g, " ")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\s+/g, " ")
      .trim();

    // Truncate to ~3000 chars to stay within token limits
    return clean.length > 3000 ? clean.substring(0, 3000) + "..." : clean;
  } catch (error) {
    console.error("URL fetch error:", error);
    return "";
  }
}

// ─── JSON Extractor ───────────────────────────────────────────────────────────

function extractJSON(raw: string): AnalysisResult {
  // Try direct parse first
  try {
    return JSON.parse(raw);
  } catch {}

  // Try extracting JSON from markdown code blocks
  const fenceMatch = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    try {
      return JSON.parse(fenceMatch[1].trim());
    } catch {}
  }

  // Try finding JSON object pattern
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      return JSON.parse(jsonMatch[0]);
    } catch {}
  }

  // Fallback response
  return {
    isReal: false,
    confidence: 50,
    verdict: "ASATYA",
    reasoning:
      "Analysis mein kuch technical issue aaya. Please dobara try karein.",
    redFlags: ["Parse error occurred"],
    suggestions: {
      hook: "Unable to generate suggestions",
      lighting: "N/A",
      editing: "N/A",
      contentTips: ["Please try again"],
    },
    viralKit: {
      caption: "SATYA AI ke saath sach ka pata lagao! 🔍",
      hashtags: ["#SatyaAI", "#FactCheck", "#India"],
    },
    rawResponse: raw,
  };
}

// ─── Main Analysis Function ───────────────────────────────────────────────────

export async function analyzeWithGemini(
  input: AnalysisInput
): Promise<AnalysisResult> {
  if (!GEMINI_API_KEY) {
    throw new Error(
      "GOOGLE_API_KEY not configured. Please add it to .env.local"
    );
  }

  const systemPrompt = buildSystemPrompt();
  const userPrompt = buildUserPrompt(input);

  // Build message parts
  const parts: object[] = [];

  // Add image if present
  if (input.type === "image" && input.imageBase64) {
    parts.push({
      inline_data: {
        mime_type: input.imageMimeType || "image/jpeg",
        data: input.imageBase64,
      },
    });
  }

  // Add text prompt
  parts.push({ text: userPrompt });

  // Build request body
  const requestBody: Record<string, unknown> = {
    contents: [
      {
        role: "user",
        parts: parts,
      },
    ],
    systemInstruction: {
      parts: [{ text: systemPrompt }],
    },
    generationConfig: {
      temperature: 0.3,
      topK: 40,
      topP: 0.95,
      maxOutputTokens: 2048,
      responseMimeType: "text/plain",
    },
    safetySettings: [
      {
        category: "HARM_CATEGORY_HARASSMENT",
        threshold: "BLOCK_MEDIUM_AND_ABOVE",
      },
      {
        category: "HARM_CATEGORY_HATE_SPEECH",
        threshold: "BLOCK_MEDIUM_AND_ABOVE",
      },
    ],
  };

  // Enable Google Search grounding for text/url/chat inputs (not image)
  if (input.type !== "image") {
    requestBody.tools = [
      {
        google_search_retrieval: {
          dynamic_retrieval_config: {
            mode: "MODE_DYNAMIC",
            dynamic_threshold: 0.3,
          },
        },
      },
    ];
  }

  // Make API call
  const response = await fetch(
    `${GEMINI_ENDPOINT}?key=${GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    }
  );

  if (!response.ok) {
    const errorBody = await response.text();
    console.error("Gemini API error:", errorBody);
    throw new Error(
      `Gemini API error: ${response.status} — ${response.statusText}`
    );
  }

  const data = await response.json();

  // Extract text from response
  const candidate = data?.candidates?.[0];
  if (!candidate) {
    throw new Error("Gemini ne koi response nahi diya.");
  }

  // Handle safety blocks
  if (candidate.finishReason === "SAFETY") {
    return {
      isReal: false,
      confidence: 0,
      verdict: "ASATYA",
      reasoning:
        "Is content ko analyze nahi kiya ja sakta safety reasons ke wajah se.",
      redFlags: ["Content flagged by safety filters"],
      suggestions: {
        hook: "Please provide appropriate content",
        lighting: "N/A",
        editing: "N/A",
        contentTips: ["Ensure content follows community guidelines"],
      },
      viralKit: {
        caption: "Sahi content share karo, sahi info spread karo! 🙏",
        hashtags: ["#SafeContent", "#FactCheck"],
      },
    };
  }

  const rawText =
    candidate?.content?.parts
      ?.map((p: { text?: string }) => p.text || "")
      .join("") || "";

  return extractJSON(rawText);
}
