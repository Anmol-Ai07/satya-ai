# 🔥 SATYA AI — Truth Detection & Viral Content Engine

> India ka sabse advanced AI-powered fact-checker aur deepfake detector.
> Powered by **Gemini 1.5 Flash** + **Google Search Grounding**

![SATYA AI](https://img.shields.io/badge/SATYA_AI-Truth_Engine-9d4edd?style=for-the-badge)
![Next.js](https://img.shields.io/badge/Next.js_14-black?style=for-the-badge&logo=next.js)
![Gemini](https://img.shields.io/badge/Gemini_1.5_Flash-blue?style=for-the-badge)
![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript)

---

## ✨ Features

| Feature | Description |
|---|---|
| 📝 **Text Analysis** | Paste any claim/news → instant fact-check |
| 🔗 **Link Analysis** | Paste URL → extract & verify with Google grounding |
| 🖼️ **Image Analysis** | Upload image → deepfake & manipulation detection |
| 💬 **Chat Mode** | Normal questions → Hinglish chatbot response |
| 🔥 **Viral Kit** | Auto-generated captions & hashtags |
| 🌐 **Web Grounding** | Real-time Google Search for latest verification |

## 🏷️ Verdict System

| Verdict | Meaning |
|---|---|
| ✅ **SAHI** | Real / Verified / True |
| ❌ **GALAT** | Fake / False / Fabricated |
| ⚠️ **BHRAMAK** | Misleading / Out of context |
| ❓ **ASATYA** | Unverified / Cannot confirm |

---

## 🚀 Quick Start

### 1. Prerequisites
- Node.js 18+ 
- npm or yarn
- Google API Key (Gemini)

### 2. Clone & Install

```bash
git clone <your-repo>
cd satya-ai
npm install
```

### 3. Configure Environment

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:
```env
GOOGLE_API_KEY=your_actual_api_key_here
```

> 🔑 Get your free API key at: https://aistudio.google.com/app/apikey

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) 🎉

### 5. Build for Production

```bash
npm run build
npm start
```

---

## 🚀 Deploy to Vercel (Recommended)

```bash
npm install -g vercel
vercel --prod
```

Set environment variable in Vercel dashboard:
- `GOOGLE_API_KEY` → your Google API key

---

## 📁 Project Structure

```
satya-ai/
├── app/
│   ├── layout.tsx          # Root layout + meta tags
│   ├── page.tsx            # Main page entry
│   └── api/
│       └── analyze/
│           └── route.ts    # 🔒 Backend API (API key safe here)
├── components/
│   └── SatyaAI.tsx         # 🎨 Complete UI component
├── lib/
│   └── gemini.ts           # 🧠 Gemini API + URL fetcher
├── styles/
│   └── globals.css         # 🎭 Animations + neon effects
├── .env.local.example      # 📋 Env template
├── tailwind.config.js      # 🎨 Custom theme
├── next.config.js
├── tsconfig.json
└── package.json
```

---

## 🔐 Security

- ✅ API key is **NEVER** exposed to frontend
- ✅ All Gemini calls happen server-side via `/api/analyze`
- ✅ Input validation on both client and server
- ✅ Error messages don't leak sensitive info

---

## 🎨 Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS + Custom CSS animations
- **AI**: Google Gemini 1.5 Flash
- **Grounding**: Google Search (real-time web verification)
- **Icons**: Lucide React

---

## 💡 Usage Tips

- **Text**: Paste any viral WhatsApp message, news headline, or claim
- **URL**: Works with news sites, Twitter/X, YouTube, Instagram
- **Image**: Upload suspicious photos, screenshots, memes
- **Chat**: Ask anything in Hindi, English, or Hinglish!

---

## 🛠️ Troubleshooting

| Issue | Solution |
|---|---|
| `GOOGLE_API_KEY not configured` | Add key to `.env.local` |
| `Rate limit exceeded` | Wait 1 min, free tier has limits |
| URL not loading | Some sites block scrapers; try pasting text |
| Image too large | Keep under 10MB |

---

## 📝 License

MIT License — Free to use and modify.

---

**SATYA AI — Sach hi sabse badi shakti hai ⚡**
