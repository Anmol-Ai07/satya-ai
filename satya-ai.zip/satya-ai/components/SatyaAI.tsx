"use client";

// components/SatyaAI.tsx
// SATYA AI — Complete UI Component

import React, {
  useState,
  useRef,
  useCallback,
  useEffect,
  DragEvent,
  ChangeEvent,
} from "react";
import {
  Search,
  Link2,
  Upload,
  MessageSquare,
  AlertTriangle,
  CheckCircle,
  XCircle,
  HelpCircle,
  Copy,
  Check,
  Sparkles,
  Zap,
  Eye,
  Shield,
  TrendingUp,
  Hash,
  X,
  ChevronDown,
  Cpu,
  Radio,
  Activity,
  FileText,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface AnalysisResult {
  isReal: boolean;
  confidence: number;
  verdict: "SAHI" | "GALAT" | "BHRAMAK" | "ASATYA";
  reasoning: string;
  redFlags: string[];
  suggestions: {
    hook: string;
    lighting: string;
    editing: string;
    contentTips: string[];
  };
  viralKit: {
    caption: string;
    hashtags: string[];
  };
}

type TabType = "text" | "url" | "image" | "chat";
type ModelType = "gemini" | "gpt" | "claude";

// ─── Constants ────────────────────────────────────────────────────────────────

const VERDICT_CONFIG = {
  SAHI: {
    label: "SAHI ✓",
    description: "Verified Real",
    color: "text-neon-green",
    bg: "bg-[rgba(6,214,160,0.1)]",
    border: "border-[rgba(6,214,160,0.4)]",
    glow: "shadow-neon-green",
    icon: CheckCircle,
    barColor: "bg-neon-green",
  },
  GALAT: {
    label: "GALAT ✗",
    description: "Fake/False",
    color: "text-neon-red",
    bg: "bg-[rgba(239,35,60,0.1)]",
    border: "border-[rgba(239,35,60,0.4)]",
    glow: "shadow-neon-red",
    icon: XCircle,
    barColor: "bg-neon-red",
  },
  BHRAMAK: {
    label: "BHRAMAK ⚠",
    description: "Misleading",
    color: "text-neon-yellow",
    bg: "bg-[rgba(255,190,11,0.1)]",
    border: "border-[rgba(255,190,11,0.4)]",
    glow: "shadow-neon-yellow",
    icon: AlertTriangle,
    barColor: "bg-neon-yellow",
  },
  ASATYA: {
    label: "ASATYA ?",
    description: "Unverified",
    color: "text-neon-cyan",
    bg: "bg-[rgba(76,201,240,0.1)]",
    border: "border-[rgba(76,201,240,0.4)]",
    glow: "shadow-neon-cyan",
    icon: HelpCircle,
    barColor: "bg-neon-cyan",
  },
};

const MODELS: { id: ModelType; label: string; note: string; active: boolean }[] = [
  { id: "gemini", label: "Gemini 1.5", note: "Active", active: true },
  { id: "gpt", label: "GPT-4o", note: "Coming Soon", active: false },
  { id: "claude", label: "Claude 3.5", note: "Coming Soon", active: false },
];

const PLACEHOLDER_EXAMPLES: Record<TabType, string> = {
  text: `Yahan text ya claim paste karo...\n\nExamples:\n• "PM Modi ne 5G free announce kiya sabke liye"\n• "COVID vaccine mein microchip hota hai"\n• Any news claim ya viral message`,
  url: "https://example.com/news-article",
  image: "",
  chat: `Kuch bhi pucho... Examples:\n• "Bhai deepfake kaise detect karte hain?"\n• "Viral content tips do"\n• "India mein fake news ka problem kya hai?"`,
};

// ─── Sub-Components ───────────────────────────────────────────────────────────

function ParticleBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="particle"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 8}s`,
            animationDuration: `${6 + Math.random() * 6}s`,
            width: `${1 + Math.random() * 3}px`,
            height: `${1 + Math.random() * 3}px`,
            opacity: 0.3 + Math.random() * 0.5,
          }}
        />
      ))}
    </div>
  );
}

function ScanningLoader() {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-8">
      {/* Hex scanner */}
      <div className="relative w-32 h-32">
        {/* Outer ring */}
        <div
          className="absolute inset-0 rounded-full border-2 border-neon-purple opacity-30"
          style={{ animation: "spin 4s linear infinite reverse" }}
        />
        {/* Middle ring */}
        <div
          className="absolute inset-3 rounded-full border border-neon-violet"
          style={{ animation: "spin 2s linear infinite" }}
        />
        {/* Inner ring */}
        <div
          className="absolute inset-6 rounded-full border border-neon-pink opacity-60"
          style={{ animation: "spin 1s linear infinite reverse" }}
        />
        {/* Center */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 rounded-full bg-neon-purple opacity-80 animate-pulse-neon" />
        </div>
        {/* Scan line overlay */}
        <div className="scan-container absolute inset-0 rounded-full overflow-hidden">
          <div className="scan-line" />
        </div>
      </div>

      {/* Status text */}
      <div className="text-center space-y-2">
        <p
          className="font-display text-neon-purple tracking-widest text-sm uppercase animate-pulse-neon"
          style={{ fontFamily: "var(--font-orbitron)" }}
        >
          Analyzing...
        </p>
        <div className="flex items-center gap-2 justify-center">
          <div className="loading-dot" />
          <div className="loading-dot" />
          <div className="loading-dot" />
        </div>
        <p className="text-slate-500 text-xs tracking-wide">
          Gemini AI + Google Search se verify ho raha hai
        </p>
      </div>

      {/* Status steps */}
      <div className="space-y-2 w-full max-w-xs">
        {[
          "Content parsing...",
          "Web verification...",
          "AI analysis...",
          "Generating verdict...",
        ].map((step, i) => (
          <div key={i} className="flex items-center gap-3">
            <div
              className="w-2 h-2 rounded-full bg-neon-purple animate-pulse-neon"
              style={{ animationDelay: `${i * 0.3}s` }}
            />
            <span
              className="text-xs text-slate-500 tracking-wider"
              style={{ animationDelay: `${i * 0.3}s` }}
            >
              {step}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wider transition-all duration-200
        border border-[rgba(157,78,221,0.3)] text-slate-400
        hover:border-neon-purple hover:text-neon-purple hover:bg-[rgba(157,78,221,0.1)]
        active:scale-95"
    >
      {copied ? (
        <>
          <Check size={12} className="text-neon-green" />
          <span className="text-neon-green">Copied!</span>
        </>
      ) : (
        <>
          <Copy size={12} />
          <span>{label || "Copy"}</span>
        </>
      )}
    </button>
  );
}

function ConfidenceBar({
  confidence,
  verdict,
}: {
  confidence: number;
  verdict: keyof typeof VERDICT_CONFIG;
}) {
  const [width, setWidth] = useState(0);
  const config = VERDICT_CONFIG[verdict];

  useEffect(() => {
    const timer = setTimeout(() => setWidth(confidence), 200);
    return () => clearTimeout(timer);
  }, [confidence]);

  const getLabel = (c: number) => {
    if (c >= 85) return "Very High";
    if (c >= 70) return "High";
    if (c >= 50) return "Medium";
    if (c >= 30) return "Low";
    return "Very Low";
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-slate-500 tracking-wider uppercase">
          Confidence Level
        </span>
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold tracking-wider ${config.color}`}>
            {getLabel(confidence)}
          </span>
          <span
            className={`font-display font-bold text-lg ${config.color}`}
            style={{ fontFamily: "var(--font-orbitron)" }}
          >
            {confidence}%
          </span>
        </div>
      </div>
      <div className="h-2 bg-[rgba(255,255,255,0.05)] rounded-full overflow-hidden border border-[rgba(255,255,255,0.05)]">
        <div
          className={`h-full rounded-full confidence-bar-fill ${config.barColor}`}
          style={{
            width: `${width}%`,
            boxShadow: `0 0 10px currentColor`,
          }}
        />
      </div>
      {/* Tick marks */}
      <div className="flex justify-between px-0.5">
        {[0, 25, 50, 75, 100].map((tick) => (
          <span key={tick} className="text-[9px] text-slate-700">
            {tick}%
          </span>
        ))}
      </div>
    </div>
  );
}

function ResultCard({ result }: { result: AnalysisResult }) {
  const config = VERDICT_CONFIG[result.verdict];
  const VerdictIcon = config.icon;

  return (
    <div className="space-y-4 animate-slide-up">
      {/* ── Verdict Header ── */}
      <div
        className={`rounded-2xl p-6 border ${config.border} ${config.bg} relative overflow-hidden`}
        style={{
          boxShadow: `0 0 40px rgba(${
            result.verdict === "SAHI"
              ? "6,214,160"
              : result.verdict === "GALAT"
              ? "239,35,60"
              : result.verdict === "BHRAMAK"
              ? "255,190,11"
              : "76,201,240"
          }, 0.2)`,
        }}
      >
        {/* Scan line */}
        <div className="scan-container absolute inset-0">
          <div className="scan-line opacity-30" />
        </div>

        <div className="relative z-10">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div
                className={`p-3 rounded-xl border ${config.border} ${config.bg}`}
              >
                <VerdictIcon size={28} className={config.color} />
              </div>
              <div>
                <p className="text-xs text-slate-500 tracking-widest uppercase mb-1">
                  Final Verdict
                </p>
                <h3
                  className={`font-display text-3xl font-black tracking-widest ${config.color} neon-text`}
                  style={{ fontFamily: "var(--font-orbitron)" }}
                >
                  {config.label}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">{config.description}</p>
              </div>
            </div>
            {/* Confidence */}
            <div className="text-right">
              <p className="text-xs text-slate-500 tracking-wider mb-1">
                AI Confidence
              </p>
              <p
                className={`font-display text-4xl font-black ${config.color}`}
                style={{ fontFamily: "var(--font-orbitron)" }}
              >
                {result.confidence}%
              </p>
            </div>
          </div>

          <div className="mt-4">
            <ConfidenceBar
              confidence={result.confidence}
              verdict={result.verdict}
            />
          </div>
        </div>
      </div>

      {/* ── Reasoning ── */}
      <div className="rounded-xl p-5 glass-panel border border-[rgba(157,78,221,0.2)] relative overflow-hidden">
        <div className="flex items-center gap-2 mb-3">
          <Eye size={16} className="text-neon-purple" />
          <h4
            className="text-xs font-bold tracking-widest text-neon-purple uppercase"
            style={{ fontFamily: "var(--font-orbitron)" }}
          >
            Analysis
          </h4>
        </div>
        <p className="text-slate-300 leading-relaxed text-sm font-medium">
          {result.reasoning}
        </p>
      </div>

      {/* ── Red Flags ── */}
      {result.redFlags && result.redFlags.length > 0 && (
        <div className="rounded-xl p-5 bg-[rgba(239,35,60,0.05)] border border-[rgba(239,35,60,0.2)]">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle size={16} className="text-neon-red" />
            <h4
              className="text-xs font-bold tracking-widest text-neon-red uppercase"
              style={{ fontFamily: "var(--font-orbitron)" }}
            >
              Red Flags
            </h4>
          </div>
          <ul className="space-y-2">
            {result.redFlags.map((flag, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                <span className="text-neon-red mt-0.5 flex-shrink-0">▶</span>
                <span>{flag}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* ── Suggestions ── */}
      <div className="rounded-xl p-5 bg-[rgba(76,201,240,0.05)] border border-[rgba(76,201,240,0.2)]">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles size={16} className="text-neon-cyan" />
          <h4
            className="text-xs font-bold tracking-widest text-neon-cyan uppercase"
            style={{ fontFamily: "var(--font-orbitron)" }}
          >
            Content Suggestions
          </h4>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {result.suggestions.hook && result.suggestions.hook !== "N/A" && (
            <div className="p-3 rounded-lg bg-[rgba(76,201,240,0.05)] border border-[rgba(76,201,240,0.15)]">
              <p className="text-[10px] text-neon-cyan font-bold tracking-widest mb-1">
                HOOK
              </p>
              <p className="text-xs text-slate-300">{result.suggestions.hook}</p>
            </div>
          )}
          {result.suggestions.lighting && result.suggestions.lighting !== "N/A" && (
            <div className="p-3 rounded-lg bg-[rgba(76,201,240,0.05)] border border-[rgba(76,201,240,0.15)]">
              <p className="text-[10px] text-neon-cyan font-bold tracking-widest mb-1">
                LIGHTING
              </p>
              <p className="text-xs text-slate-300">{result.suggestions.lighting}</p>
            </div>
          )}
          {result.suggestions.editing && result.suggestions.editing !== "N/A" && (
            <div className="p-3 rounded-lg bg-[rgba(76,201,240,0.05)] border border-[rgba(76,201,240,0.15)]">
              <p className="text-[10px] text-neon-cyan font-bold tracking-widest mb-1">
                EDITING
              </p>
              <p className="text-xs text-slate-300">{result.suggestions.editing}</p>
            </div>
          )}
        </div>
        {result.suggestions.contentTips &&
          result.suggestions.contentTips.length > 0 && (
            <div className="mt-3">
              <p className="text-[10px] text-neon-cyan font-bold tracking-widest mb-2">
                CONTENT TIPS
              </p>
              <ul className="space-y-1.5">
                {result.suggestions.contentTips.map((tip, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-slate-300">
                    <Zap size={10} className="text-neon-cyan mt-1 flex-shrink-0" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          )}
      </div>

      {/* ── Viral Kit ── */}
      <div className="rounded-xl p-5 bg-[rgba(247,37,133,0.05)] border border-[rgba(247,37,133,0.2)]">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp size={16} className="text-neon-pink" />
          <h4
            className="text-xs font-bold tracking-widest text-neon-pink uppercase"
            style={{ fontFamily: "var(--font-orbitron)" }}
          >
            🔥 Viral Kit
          </h4>
        </div>

        {/* Caption */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-[10px] text-neon-pink font-bold tracking-widest">
              CAPTION
            </p>
            <CopyButton text={result.viralKit.caption} label="Copy Caption" />
          </div>
          <div className="p-3 rounded-lg bg-[rgba(247,37,133,0.05)] border border-[rgba(247,37,133,0.15)]">
            <p className="text-sm text-slate-200 leading-relaxed">
              {result.viralKit.caption}
            </p>
          </div>
        </div>

        {/* Hashtags */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-[10px] text-neon-pink font-bold tracking-widest flex items-center gap-1">
              <Hash size={10} /> HASHTAGS
            </p>
            <CopyButton
              text={result.viralKit.hashtags.join(" ")}
              label="Copy All"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {result.viralKit.hashtags.map((tag, i) => (
              <button
                key={i}
                onClick={async () => {
                  await navigator.clipboard.writeText(tag);
                }}
                className="px-3 py-1 rounded-full text-xs font-bold tracking-wide
                  bg-[rgba(247,37,133,0.1)] border border-[rgba(247,37,133,0.3)] text-neon-pink
                  hover:bg-[rgba(247,37,133,0.2)] hover:border-neon-pink
                  transition-all duration-200 active:scale-95"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN COMPONENT ──────────────────────────────────────────────────────────

export default function SatyaAI() {
  // ── State ─────────────────────────────────────────────────────────────────
  const [activeTab, setActiveTab] = useState<TabType>("text");
  const [selectedModel, setSelectedModel] = useState<ModelType>("gemini");
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [textInput, setTextInput] = useState("");
  const [urlInput, setUrlInput] = useState("");
  const [chatInput, setChatInput] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string>("image/jpeg");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [analysisCount, setAnalysisCount] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // ── Effects ───────────────────────────────────────────────────────────────

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowModelDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Auto-scroll to results
  useEffect(() => {
    if (result && resultRef.current) {
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);
    }
  }, [result]);

  // ── Image Processing ──────────────────────────────────────────────────────

  const processImageFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) {
      setError("Sirf image files allowed hain (JPG, PNG, GIF, WebP)");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError("Image size 10MB se zyada nahi honi chahiye");
      return;
    }

    setImageFile(file);
    setImageMimeType(file.type);
    setError(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setImagePreview(dataUrl);
      // Extract base64 only (without data:image/...;base64, prefix)
      const base64 = dataUrl.split(",")[1];
      setImageBase64(base64);
    };
    reader.readAsDataURL(file);
  }, []);

  // ── Drag & Drop ───────────────────────────────────────────────────────────

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      processImageFile(file);
      setActiveTab("image");
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processImageFile(file);
  };

  // ── Analysis ──────────────────────────────────────────────────────────────

  const handleAnalyze = async () => {
    setError(null);
    setResult(null);

    // Validate input
    if (activeTab === "text" && !textInput.trim()) {
      setError("Kuch text ya claim paste karo pehle!");
      return;
    }
    if (activeTab === "url" && !urlInput.trim()) {
      setError("URL paste karo pehle!");
      return;
    }
    if (activeTab === "chat" && !chatInput.trim()) {
      setError("Kuch pucho ya likho pehle!");
      return;
    }
    if (activeTab === "image" && !imageBase64) {
      setError("Pehle image upload karo!");
      return;
    }

    setLoading(true);

    try {
      const payload: Record<string, unknown> = { type: activeTab };

      if (activeTab === "text") payload.content = textInput.trim();
      else if (activeTab === "url") payload.content = urlInput.trim();
      else if (activeTab === "chat") payload.content = chatInput.trim();
      else if (activeTab === "image") {
        payload.imageBase64 = imageBase64;
        payload.imageMimeType = imageMimeType;
      }

      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || `Server error: ${response.status}`);
      }

      if (!data.success || !data.result) {
        throw new Error("Invalid response from server");
      }

      setResult(data.result);
      setAnalysisCount((c) => c + 1);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setError(null);
    setTextInput("");
    setUrlInput("");
    setChatInput("");
    setImageFile(null);
    setImagePreview(null);
    setImageBase64(null);
  };

  // ── Keyboard shortcut (Ctrl+Enter) ────────────────────────────────────────
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      handleAnalyze();
    }
  };

  // ── Render ────────────────────────────────────────────────────────────────

  const activeModel = MODELS.find((m) => m.id === selectedModel) || MODELS[0];
  const currentInput =
    activeTab === "text"
      ? textInput
      : activeTab === "url"
      ? urlInput
      : activeTab === "chat"
      ? chatInput
      : imageBase64
      ? "image_ready"
      : "";

  return (
    <div
      className="min-h-screen bg-void grid-bg relative"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <ParticleBackground />

      {/* ── Global Drag Overlay ── */}
      {dragOver && (
        <div className="fixed inset-0 z-50 bg-[rgba(157,78,221,0.1)] backdrop-blur-sm border-4 border-dashed border-neon-purple flex items-center justify-center">
          <div className="text-center">
            <Upload size={60} className="text-neon-purple mx-auto mb-4 animate-float" />
            <p
              className="font-display text-2xl font-bold text-neon-purple tracking-widest"
              style={{ fontFamily: "var(--font-orbitron)" }}
            >
              Drop Image Here
            </p>
            <p className="text-slate-400 mt-2">Image analyze karne ke liye drop karo</p>
          </div>
        </div>
      )}

      <div className="relative z-10 max-w-4xl mx-auto px-4 py-8 md:py-12">

        {/* ════════════ HEADER ════════════ */}
        <header className="text-center mb-10">
          {/* Top badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[rgba(157,78,221,0.4)] bg-[rgba(157,78,221,0.1)] mb-6">
            <Radio size={10} className="text-neon-purple animate-pulse-neon" />
            <span
              className="text-[10px] tracking-[0.3em] text-neon-purple uppercase font-bold"
              style={{ fontFamily: "var(--font-orbitron)" }}
            >
              AI Truth Engine v2.0
            </span>
            <span className="text-[10px] text-slate-500">•</span>
            <span className="text-[10px] text-slate-400">
              {analysisCount} analyses done
            </span>
          </div>

          {/* Logo */}
          <div className="mb-3">
            <h1
              className="font-display font-black text-5xl md:text-7xl tracking-widest text-white glitch"
              style={{ fontFamily: "var(--font-orbitron)" }}
              data-text="SATYA AI"
            >
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-purple via-neon-violet to-neon-pink">
                SATYA
              </span>{" "}
              <span className="text-white">AI</span>
            </h1>
          </div>

          <p
            className="text-slate-400 text-lg tracking-wide font-medium max-w-xl mx-auto"
            style={{ fontFamily: "var(--font-rajdhani)" }}
          >
            Fake news, deepfakes aur misinformation ko{" "}
            <span className="text-neon-purple font-bold">instantly detect</span> karo
          </p>

          {/* Live stats bar */}
          <div className="flex items-center justify-center gap-6 mt-5 flex-wrap">
            {[
              { icon: Shield, label: "Fact Checking", color: "text-neon-green" },
              { icon: Eye, label: "Deepfake Detection", color: "text-neon-cyan" },
              { icon: Activity, label: "Web Grounding", color: "text-neon-purple" },
            ].map(({ icon: Icon, label, color }, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <Icon size={12} className={color} />
                <span className={`text-xs tracking-wider ${color} font-semibold`}>
                  {label}
                </span>
              </div>
            ))}
          </div>
        </header>

        {/* ════════════ MAIN CARD ════════════ */}
        <div className="glass-panel rounded-2xl overflow-hidden shadow-neon-md">

          {/* ── Model Selector Bar ── */}
          <div className="border-b border-[rgba(157,78,221,0.15)] px-5 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cpu size={14} className="text-neon-purple" />
              <span
                className="text-[10px] text-slate-500 tracking-widest uppercase"
                style={{ fontFamily: "var(--font-space-mono)" }}
              >
                Model
              </span>
            </div>

            {/* Model dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setShowModelDropdown(!showModelDropdown)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[rgba(157,78,221,0.3)] bg-[rgba(157,78,221,0.05)]
                  hover:border-neon-purple hover:bg-[rgba(157,78,221,0.1)] transition-all duration-200"
              >
                <span
                  className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse"
                />
                <span
                  className="text-xs font-bold text-slate-300 tracking-wider"
                  style={{ fontFamily: "var(--font-orbitron)" }}
                >
                  {activeModel.label}
                </span>
                <ChevronDown
                  size={12}
                  className={`text-slate-500 transition-transform duration-200 ${
                    showModelDropdown ? "rotate-180" : ""
                  }`}
                />
              </button>

              {showModelDropdown && (
                <div className="absolute right-0 top-full mt-2 w-48 rounded-xl border border-[rgba(157,78,221,0.3)] bg-panel shadow-neon-md z-50 overflow-hidden animate-fade-in">
                  {MODELS.map((model) => (
                    <button
                      key={model.id}
                      onClick={() => {
                        if (model.active) setSelectedModel(model.id);
                        setShowModelDropdown(false);
                      }}
                      className={`w-full flex items-center justify-between px-4 py-3 text-left transition-colors duration-150
                        ${
                          model.active
                            ? "hover:bg-[rgba(157,78,221,0.1)] cursor-pointer"
                            : "opacity-40 cursor-not-allowed"
                        }
                        ${selectedModel === model.id ? "bg-[rgba(157,78,221,0.1)]" : ""}
                      `}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            model.active ? "bg-neon-green" : "bg-slate-600"
                          }`}
                        />
                        <span
                          className={`text-xs font-bold tracking-wider ${
                            selectedModel === model.id
                              ? "text-neon-purple"
                              : "text-slate-300"
                          }`}
                          style={{ fontFamily: "var(--font-orbitron)" }}
                        >
                          {model.label}
                        </span>
                      </div>
                      <span
                        className={`text-[9px] tracking-widest uppercase ${
                          model.active ? "text-neon-green" : "text-slate-600"
                        }`}
                      >
                        {model.note}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ── Tab Navigation ── */}
          <div className="border-b border-[rgba(157,78,221,0.15)] px-5">
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
              {(
                [
                  { id: "text", label: "Text / Claim", icon: FileText },
                  { id: "url", label: "Link / URL", icon: Link2 },
                  { id: "image", label: "Image", icon: Eye },
                  { id: "chat", label: "Chat", icon: MessageSquare },
                ] as const
              ).map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => {
                    setActiveTab(id);
                    setError(null);
                    setResult(null);
                  }}
                  className={`tab-btn flex items-center gap-2 whitespace-nowrap ${
                    activeTab === id ? "active" : ""
                  }`}
                >
                  <Icon size={13} />
                  <span style={{ fontFamily: "var(--font-rajdhani)" }}>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* ── Input Area ── */}
          <div className="p-5">

            {/* TEXT TAB */}
            {activeTab === "text" && (
              <div className="neon-border rounded-xl p-4">
                <textarea
                  className="input-field min-h-[140px]"
                  placeholder={PLACEHOLDER_EXAMPLES.text}
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  maxLength={5000}
                />
                <div className="flex justify-end mt-2">
                  <span className="text-[10px] text-slate-700 font-mono">
                    {textInput.length}/5000
                  </span>
                </div>
              </div>
            )}

            {/* URL TAB */}
            {activeTab === "url" && (
              <div className="space-y-3">
                <div className="neon-border rounded-xl px-4 py-3 flex items-center gap-3">
                  <Link2 size={16} className="text-neon-purple flex-shrink-0" />
                  <input
                    type="url"
                    className="input-field"
                    placeholder={PLACEHOLDER_EXAMPLES.url}
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAnalyze()}
                  />
                  {urlInput && (
                    <button
                      onClick={() => setUrlInput("")}
                      className="text-slate-600 hover:text-slate-400 transition-colors"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
                <p className="text-xs text-slate-600 px-1">
                  💡 News articles, social media posts, YouTube links, tweet URLs — sab kuch
                </p>
              </div>
            )}

            {/* IMAGE TAB */}
            {activeTab === "image" && (
              <div className="space-y-4">
                {/* Upload area */}
                <div
                  onClick={() => !imagePreview && fileInputRef.current?.click()}
                  className={`relative rounded-xl border-2 border-dashed transition-all duration-300 
                    ${
                      imagePreview
                        ? "border-[rgba(157,78,221,0.3)]"
                        : "border-[rgba(157,78,221,0.3)] hover:border-neon-purple cursor-pointer"
                    }
                    bg-[rgba(157,78,221,0.03)]`}
                >
                  {imagePreview ? (
                    <div className="relative">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-full max-h-72 object-contain rounded-xl"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[rgba(0,0,0,0.5)] to-transparent rounded-xl" />
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
                          <span className="text-xs text-white font-semibold">
                            {imageFile?.name}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            ({((imageFile?.size || 0) / 1024).toFixed(0)}KB)
                          </span>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setImageFile(null);
                            setImagePreview(null);
                            setImageBase64(null);
                          }}
                          className="flex items-center gap-1 px-3 py-1 rounded-lg bg-[rgba(239,35,60,0.2)] border border-[rgba(239,35,60,0.4)] text-neon-red text-xs font-bold hover:bg-[rgba(239,35,60,0.3)] transition-colors"
                        >
                          <X size={10} /> Remove
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 px-4">
                      <div className="w-16 h-16 rounded-full bg-[rgba(157,78,221,0.1)] border border-[rgba(157,78,221,0.3)] flex items-center justify-center mb-4 hover:scale-110 transition-transform">
                        <span className="text-3xl text-neon-purple font-bold">+</span>
                      </div>
                      <p className="text-slate-300 font-semibold text-sm">
                        Click to upload or drag & drop
                      </p>
                      <p className="text-xs text-slate-600 mt-1">
                        JPG, PNG, GIF, WebP — max 10MB
                      </p>
                      <p className="text-xs text-neon-purple mt-2 font-semibold">
                        Deepfake • Manipulation • AI-generated detection
                      </p>
                    </div>
                  )}
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />

                {/* Upload button */}
                {!imagePreview && (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-3 rounded-xl border border-[rgba(157,78,221,0.3)] bg-[rgba(157,78,221,0.05)]
                      text-neon-purple text-sm font-bold tracking-wider
                      hover:bg-[rgba(157,78,221,0.1)] hover:border-neon-purple
                      transition-all duration-200 flex items-center justify-center gap-2"
                  >
                    <Upload size={16} />
                    <span style={{ fontFamily: "var(--font-orbitron)" }}>
                      Browse Image
                    </span>
                  </button>
                )}
              </div>
            )}

            {/* CHAT TAB */}
            {activeTab === "chat" && (
              <div className="neon-border rounded-xl p-4">
                <textarea
                  className="input-field min-h-[120px]"
                  placeholder={PLACEHOLDER_EXAMPLES.chat}
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  maxLength={2000}
                />
                <div className="flex justify-between items-center mt-2">
                  <span className="text-[10px] text-slate-600">
                    Ctrl+Enter to send
                  </span>
                  <span className="text-[10px] text-slate-700 font-mono">
                    {chatInput.length}/2000
                  </span>
                </div>
              </div>
            )}

            {/* ── Error ── */}
            {error && (
              <div className="mt-3 p-3 rounded-xl bg-[rgba(239,35,60,0.1)] border border-[rgba(239,35,60,0.3)] flex items-center gap-3 animate-fade-in">
                <AlertTriangle size={16} className="text-neon-red flex-shrink-0" />
                <p className="text-sm text-neon-red">{error}</p>
                <button
                  onClick={() => setError(null)}
                  className="ml-auto text-slate-500 hover:text-slate-300"
                >
                  <X size={14} />
                </button>
              </div>
            )}

            {/* ── CTA Button ── */}
            <div className="mt-4 flex gap-3">
              <button
                onClick={handleAnalyze}
                disabled={loading || !currentInput}
                className={`neon-btn flex-1 rounded-xl flex items-center justify-center gap-2 py-3.5
                  disabled:opacity-40 disabled:cursor-not-allowed disabled:pointer-events-none`}
              >
                <span className="relative z-10 flex items-center gap-2">
                  <Search size={16} />
                  <span style={{ fontFamily: "var(--font-orbitron)" }}>
                    {loading
                      ? "Analyzing..."
                      : activeTab === "chat"
                      ? "Send"
                      : "Analyze Now"}
                  </span>
                </span>
              </button>

              {result && (
                <button
                  onClick={handleReset}
                  className="px-5 py-3 rounded-xl border border-[rgba(255,255,255,0.1)] text-slate-400
                    hover:border-[rgba(255,255,255,0.2)] hover:text-slate-200
                    transition-all duration-200 text-sm font-bold tracking-wider"
                >
                  Reset
                </button>
              )}
            </div>

            <p className="text-center text-[10px] text-slate-700 mt-2 tracking-wider">
              Powered by Gemini 1.5 Flash + Google Search Grounding
            </p>
          </div>
        </div>

        {/* ════════════ RESULTS ════════════ */}
        <div ref={resultRef}>
          {loading && (
            <div className="mt-6 glass-panel rounded-2xl border border-[rgba(157,78,221,0.2)] overflow-hidden animate-fade-in">
              <div className="px-5 py-3 border-b border-[rgba(157,78,221,0.15)] flex items-center gap-2">
                <Activity size={14} className="text-neon-purple animate-pulse" />
                <span
                  className="text-xs text-neon-purple tracking-widest uppercase font-bold"
                  style={{ fontFamily: "var(--font-orbitron)" }}
                >
                  SATYA AI Processing
                </span>
              </div>
              <ScanningLoader />
            </div>
          )}

          {result && !loading && (
            <div className="mt-6 glass-panel rounded-2xl overflow-hidden border border-[rgba(157,78,221,0.2)] animate-fade-in">
              <div className="px-5 py-3 border-b border-[rgba(157,78,221,0.15)] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield size={14} className="text-neon-purple" />
                  <span
                    className="text-xs text-neon-purple tracking-widest uppercase font-bold"
                    style={{ fontFamily: "var(--font-orbitron)" }}
                  >
                    Analysis Result
                  </span>
                </div>
                <span className="text-[10px] text-slate-600 font-mono">
                  #{analysisCount.toString().padStart(4, "0")}
                </span>
              </div>
              <div className="p-5">
                <ResultCard result={result} />
              </div>
            </div>
          )}
        </div>

        {/* ════════════ FOOTER ════════════ */}
        <footer className="mt-12 text-center">
          <div className="flex items-center justify-center gap-4 mb-3 flex-wrap">
            {["Gemini 1.5 Flash", "Google Search", "Real-time Grounding"].map(
              (tech, i) => (
                <span
                  key={i}
                  className="text-[10px] text-slate-600 tracking-widest uppercase border border-[rgba(255,255,255,0.05)] px-3 py-1 rounded-full"
                >
                  {tech}
                </span>
              )
            )}
          </div>
          <p className="text-xs text-slate-700 tracking-wider">
            SATYA AI — Sach hi sabse badi shakti hai ⚡
          </p>
        </footer>
      </div>
    </div>
  );
}
